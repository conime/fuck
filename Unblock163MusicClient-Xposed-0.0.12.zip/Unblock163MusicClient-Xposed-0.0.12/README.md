# Unblock163MusicClient - Xposed

Xposed version of EraserKing's [Unblock163MusicClient](https://github.com/EraserKing/Unblock163MusicClient).

Compatible with the 3.x app.

## Downlad
No apks here. Just build it yourself.

## Thanks

Thanks EraserKing for his Original Windows version [https://github.com/EraserKing/Unblock163MusicClient]

Thanks yanunon for his API analysis! [https://github.com/yanunon/NeteaseCloudMusic]